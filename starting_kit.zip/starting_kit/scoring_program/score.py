#!/usr/bin/env python



import os
from sys import argv

import libscores
import my_metric
import yaml
from libscores import *
from solution import read_solutions


# Default I/O directories:
root_dir = "../"
default_solution_dir = root_dir + "sample_data"
default_prediction_dir = root_dir + "sample_result_submission"
default_score_dir = root_dir + "scoring_output"
default_data_name = "fair_universe"

# Debug flag 0: no debug, 1: show all scores, 2: also show version amd listing of dir
debug_mode = 0

# Constant used for a missing score
missing_score = -0.999999

# Version number
scoring_version = 1.0

# =============================== MAIN ========================================

if __name__ == "__main__":

    #### INPUT/OUTPUT: Get input and output directory names
    if len(argv) == 1:  # Use the default data directories if no arguments are provided
        solution_dir = default_solution_dir
        prediction_dir = default_prediction_dir
        score_dir = default_score_dir
        data_name = default_data_name
    elif len(argv) == 3: # The current default configuration of Codalab
        solution_dir = os.path.join(argv[1], 'ref')
        prediction_dir = os.path.join(argv[1], 'res')
        score_dir = argv[2]
        data_name = default_data_name
    elif len(argv) == 4:
        solution_dir = argv[1]
        prediction_dir = argv[2]
        score_dir = argv[3]
        data_name = default_data_name
    else: 
        swrite('\n*** WRONG NUMBER OF ARGUMENTS ***\n\n')
        exit(1)

        
    # Create the output directory, if it does not already exist and open output files
    mkdir(score_dir)
    score_file = open(os.path.join(score_dir, 'scores.txt'), 'w')
    html_file = open(os.path.join(score_dir, 'scores.html'), 'w')

    # Get the metric
    metric_name, scoring_function = get_metric()
    print("###-------------------------------------###")
    print("### Using metric : ", metric_name)
    print("###-------------------------------------###\n\n")
    
    
    #Solution Arrays
    # 2 arrays: train, and test
    solution_names, solutions = read_solutions(solution_dir)
 
    for i, solution_name in enumerate(solution_names):
        
        set_num = i + 1  # 1-indexed
        score_name = 'set%s_score' % set_num
        try:

            # Get the train prediction from the res subdirectory (must end with '.predict')
            predict_file = os.path.join(prediction_dir, data_name + '_'+solution_name+'.predict')
            if not os.path.isfile(predict_file):
                print("#--ERROR--# "+solution_name.capitalize()+" predict file NOT Found!")
                raise IOError("#--ERROR--# "+solution_name.capitalize()+" predict file NOT Found!")

            # Read the solution and prediction values into numpy arrays
            prediction = read_array(predict_file)
            solution = solutions[i]
            if (len(solution) != len(prediction)): 
                print("#--ERROR--# Prediction length={} and Solution length={}".format(len(prediction), len(solution)))
                raise ValueError("Prediction length={} and Solution length={}".format(len(prediction), len(solution)))

            try:
                # Compute the score prescribed by the metric file 
                score = scoring_function(solution, prediction)
                print(
                    "======= Set %d" % set_num + " (" + data_name.capitalize() + "_" + solution_name + "): " + metric_name + "(" + score_name + ")=%0.12f =======" % score)
                html_file.write(
                    "<pre>======= Set %d" % set_num + " (" + data_name.capitalize() + "_" + solution_name + "): " + metric_name + "(" + score_name + ")=%0.12f =======\n" % score)
            except:
                print("#--ERROR--# Error in calculation of the specific score of the task")
                raise Exception('Error in calculation of the specific score of the task')

            if debug_mode > 0:
                scores = compute_all_scores(solution, prediction)
                write_scores(html_file, scores)

        except Exception as inst:
            score = missing_score
            print(
                "======= Set %d" % set_num + " (" + data_name.capitalize() + "_" + solution_name + "): " + metric_name + "(" + score_name + ")=ERROR =======")
            html_file.write(
                "======= Set %d" % set_num + " (" + data_name.capitalize() + "_" + solution_name +  "): " + metric_name + "(" + score_name + ")=ERROR =======\n")
            print
            inst

        # Write score corresponding to selected task and metric to the output file
        score_file.write(score_name + ": %0.12f\n" % score)

    # End loop for solution_file in solution_names

    # Read the execution time and add it to the scores:
    try:
        metadata = yaml.load(open(os.path.join(input_dir, 'res', 'metadata'), 'r'))
        score_file.write("Duration: %0.6f\n" % metadata['elapsedTime'])
    except:
        score_file.write("Duration: 0\n")

        html_file.close()
    score_file.close()

    # Lots of debug stuff
    if debug_mode > 1:
        swrite('\n*** SCORING PROGRAM: PLATFORM SPECIFICATIONS ***\n\n')
        show_platform()
        show_io(prediction_dir, score_dir)
        show_version(scoring_version)
        
        
        
        
        
        