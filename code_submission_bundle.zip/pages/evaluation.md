# Evaluation

Participants are judged based on the performance of their submitted solutions. The metric of evaluation is Area under the ROC Curve (AUC).

To know how AUC works, check this blog post: https://arize.com/blog/what-is-auc

AUC is calcualted using scikit-learn : https://scikit-learn.org/stable/modules/generated/sklearn.metrics.auc.html
