# Terms and Conditions

In order to participate in FAIR-UNIVERSE competition, all participants have to follow the given terms and conditions.

Note: The organizing team reserves the right to modify/add terms and conditions.

This challenge is for educational purposes only and no prizes are granted. It is governed by the [General ChaLearn Contest Rules](http://www.causality.inf.ethz.ch/GeneralChalearnContestRuleTerms.html)
