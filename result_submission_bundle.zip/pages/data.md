# Data

The data used in this competition is generated using two distributions. Each datapoint belongs to either class background (0) or class signal (1).

For simplicity, both distributions are gaussians with known parameters.

### Data Statistics
Train set : 10,000 datapoints (5000 for each class)
Test set : 5,000 datapoints (2500 for each class)


